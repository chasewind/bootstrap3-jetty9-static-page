*************
Miscellaneous
*************

.. automodule:: numpy.doc.misc

.. automodule:: numpy.doc.methods_vs_functions
